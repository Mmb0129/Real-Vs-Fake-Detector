from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from tensorflow.keras.applications.vgg16 import VGG16, preprocess_input
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import GlobalAveragePooling2D

import numpy as np
import joblib
import os
from PIL import Image

application = Flask(__name__)  # Renamed to 'application' for AWS compatibility
CORS(application)  # Enable CORS for all routes

# Load your trained pipeline
model_pipeline = joblib.load("svm_vgg_pipeline.pkl")

# VGG16 feature extractor
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
vgg_model = Sequential([base_model, GlobalAveragePooling2D()])

def extract_vgg_features(img):
    img = img.resize((224, 224))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array = preprocess_input(img_array)
    features = vgg_model.predict(img_array)
    return features.flatten().reshape(1, -1)

# Serve your HTML page
@application.route('/')
def home():
    return render_template('index.html')  # Ensure index.html is inside the 'templates' folder

# Handle prediction
@application.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    file = request.files['image']
    img = Image.open(file.stream).convert("RGB")
    features = extract_vgg_features(img)
    prediction = model_pipeline.predict(features)[0]
    return jsonify({'prediction': prediction})

if __name__ == '__main__':
    application.run(debug=True)
